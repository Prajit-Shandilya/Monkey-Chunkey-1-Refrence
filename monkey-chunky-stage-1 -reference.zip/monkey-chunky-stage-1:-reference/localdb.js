const db={
  "the": {
		"chunks": ["th", "e"],
		"phones": ["DH", "AH"]
	},
	"of": {
		"chunks": ["o", "f"],
		"phones": ["AH", "V"]
	},
	"and": {
		"chunks": ["a", "n", "d"],
		"phones": ["AH", "N", "D"]
	},
	"to": {
		"chunks": ["t", "o"],
		"phones": ["T", "UW"]
	},
	"a": {
		"chunks": ["a"],
		"phones": ["AH"]
	}
}

export default db;